extends Control

const MCNumberDisplay = preload("res://scripts/ui/MCNumberDisplay.gd")

# 原版 HitsUI：本版使用 FFDec 从原版 fight.swf 导出的 hits_mc 56 帧作为时间轴图层，
# 动态数字仍按原版 MCNumber.as 用 hits_num_mc 数字帧组合。
# 资源来源：FighterTester_ORG.swf 内嵌 /../libs_swf/fight.swf -> DefineSprite_55_hits_mc / DefineSprite_22_hits_num_mc。

const ORIGINAL_FPS: float = 30.0
# 原版 hits_mc 的 fadout 末段会把数字 / HITS 压扁到接近 0。
# Godot 逐帧 + 独立数字层复刻时，最后 1~2 帧容易留下 1px 彩色线。
# 这里在进入末段时直接视为原版 fadout_fin 完成，立即隐藏整组，避免残影。
const FADOUT_HIDE_FRAME: float = 53.0
const DIGIT_WIDTH: float = 35.0
const DIGIT_BASE_X: float = -23.5
const DIGIT_BASE_Y: float = 0.0
const HITS_SEQUENCE_DIR: String = "res://assets/ui/fight/hits_mc_sequence/"

var is_p1_side: bool = true
var original_position: Vector2 = Vector2.ZERO
var hits_timeline_rect: TextureRect
var number_mc: Control
var showing: bool = false
var anim_state: String = "hidden"
var frame_pos: float = 0.0
var current_combo: int = 0
var last_combo: int = 0
var initialized_origin: bool = false
var hits_frames: Array[Texture2D] = []

func setup(new_is_p1: bool) -> void:
	is_p1_side = new_is_p1
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_load_hits_frames()
	_make_children()
	visible = false
	set_process(true)

func show_hits(combo_value: int) -> void:
	if combo_value < 1:
		hide_hits()
		return
	current_combo = combo_value
	if not initialized_origin:
		original_position = position
		initialized_origin = true
	_update_number_and_alignment(combo_value)
	visible = true
	show()
	modulate = Color(1.0, 1.0, 1.0, 1.0)
	_set_parts_visible(true)
	if hits_timeline_rect != null:
		hits_timeline_rect.size = Vector2(196.0, 72.0)
		hits_timeline_rect.modulate = Color(1.0, 1.0, 1.0, 1.0)
	if number_mc != null:
		number_mc.modulate = Color(1.0, 1.0, 1.0, 1.0)
	if showing:
		if combo_value != last_combo:
			anim_state = "update"
			frame_pos = 29.0
	else:
		showing = true
		anim_state = "fadin"
		frame_pos = 9.0
	last_combo = combo_value
	_apply_timeline_frame(frame_pos)

func hide_hits() -> void:
	# 当前 Godot 版把原版 hits_mc 与 ct 数字层分开绘制。
	# 若继续播放 fadout，ct 数字层和 HITS 贴图在压缩末段会留下 1px 彩色残线。
	# 按用户要求，combo 中断时直接清空整组显示，避免任何残影。
	if not showing and not visible:
		return
	_finish_hidden()

func _process(delta: float) -> void:
	if anim_state == "hidden":
		return
	frame_pos += delta * ORIGINAL_FPS
	if anim_state == "fadin" and frame_pos >= 19.0:
		frame_pos = 19.0
		anim_state = "hold"
	elif anim_state == "update" and frame_pos >= 37.0:
		frame_pos = 37.0
		anim_state = "hold"
	elif anim_state == "fadout" and frame_pos >= FADOUT_HIDE_FRAME:
		_finish_hidden()
		return
	_apply_timeline_frame(frame_pos)

func _finish_hidden() -> void:
	frame_pos = 0.0
	anim_state = "hidden"
	showing = false
	current_combo = 0
	last_combo = 0
	visible = false
	hide()
	modulate = Color(1.0, 1.0, 1.0, 0.0)
	position = original_position
	_set_parts_visible(false)
	# 强制清空贴图与数字层，避免 combo>=2 消失时 Godot 仍渲染 fadout 末帧的 1px 阴影/彩线。
	if number_mc != null:
		number_mc.scale = Vector2.ZERO
		number_mc.position = Vector2(DIGIT_BASE_X, DIGIT_BASE_Y)
		number_mc.modulate = Color(1.0, 1.0, 1.0, 0.0)
		number_mc.visible = false
	if hits_timeline_rect != null:
		hits_timeline_rect.texture = null
		hits_timeline_rect.size = Vector2.ZERO
		hits_timeline_rect.modulate = Color(1.0, 1.0, 1.0, 0.0)
		hits_timeline_rect.visible = false
	queue_redraw()

func _set_parts_visible(value: bool) -> void:
	if hits_timeline_rect != null:
		hits_timeline_rect.visible = value
	if number_mc != null:
		number_mc.visible = value

func _load_hits_frames() -> void:
	hits_frames.clear()
	var index: int = 0
	while index < 80:
		var path: String = HITS_SEQUENCE_DIR + "%04d.png" % index
		if not ResourceLoader.exists(path):
			break
		var res: Resource = load(path)
		if res is Texture2D:
			hits_frames.append(res as Texture2D)
		index += 1

func _make_children() -> void:
	for child: Node in get_children():
		remove_child(child)
		child.queue_free()
	hits_timeline_rect = TextureRect.new()
	hits_timeline_rect.name = "hits_mc_ffdec"
	if not hits_frames.is_empty():
		hits_timeline_rect.texture = hits_frames[0]
	hits_timeline_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	hits_timeline_rect.stretch_mode = TextureRect.STRETCH_KEEP
	hits_timeline_rect.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	hits_timeline_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	# 原版 mc_018.xml：hitsmc 位于 x=65.05, y=3。
	# FFDec 导出的 hits_mc_sequence 单帧已经带有纵向画布空白，之前把整张图贴在 (0,0)，
	# 导致 HITS 文字从 x=0 开始，和 ct 数字层重合。这里把 hitsmc 层按原版 Matrix 放回右侧。
	hits_timeline_rect.position = Vector2(65.05, 0.0)
	hits_timeline_rect.size = Vector2(196.0, 72.0)
	# P2 一侧的整体位置由外层 FightHud 的 hits2 Matrix 控制；原版 hits2 不是简单镜像整个 MC，这里不擅自翻转原始帧。
	add_child(hits_timeline_rect)
	hits_timeline_rect.visible = false

	number_mc = MCNumberDisplay.new()
	number_mc.name = "ct"
	number_mc.size = Vector2(180.0, 70.0)
	number_mc.call("setup", "res://assets/ui/fight/mcnumber/hits", DIGIT_WIDTH, 0, HORIZONTAL_ALIGNMENT_LEFT)
	add_child(number_mc)
	number_mc.visible = false

func _update_number_and_alignment(combo_value: int) -> void:
	if number_mc != null and number_mc.has_method("set_number"):
		number_mc.call("set_number", combo_value)
	var digits: int = max(1, str(combo_value).length())
	var num_width: float = DIGIT_WIDTH * float(digits)
	var xoffset: float = -num_width + 45.0
	if is_p1_side:
		position.x = original_position.x - xoffset
	else:
		position.x = original_position.x

func _apply_timeline_frame(frame_value: float) -> void:
	if anim_state == "fadout" and frame_value >= FADOUT_HIDE_FRAME:
		_finish_hidden()
		return
	var frame_index: int = clampi(int(round(frame_value)) - 1, 0, max(0, hits_frames.size() - 1))
	# FFDec 导出的 hits_mc 序列会把 hitsmc 的左右两个补间状态交替输出，直接逐帧播放会造成 HITS 文字左右闪动。
	# 原版 HitsUI.as 只有一个 _mc.gotoAndPlay("fadin/update/fadout")，并不会每帧切换左右位置；
	# 这里固定使用同一侧的原始帧，数字层仍按 mc_018.xml 的 ct 关键帧单独补间。
	if frame_index % 2 == 0 and frame_index + 1 < hits_frames.size():
		frame_index += 1
	if hits_timeline_rect != null and not hits_frames.is_empty():
		hits_timeline_rect.size = Vector2(196.0, 72.0)
		hits_timeline_rect.modulate = Color(1.0, 1.0, 1.0, 1.0)
		hits_timeline_rect.texture = hits_frames[frame_index]
	var digit_transform: Vector4 = _digit_transform_at(frame_value)
	var digits: int = max(1, str(maxi(current_combo, 0)).length())
	var num_width: float = DIGIT_WIDTH * float(digits)
	var xoffset: float = -num_width + 45.0
	if number_mc != null:
		number_mc.scale = Vector2(digit_transform.x, digit_transform.y)
		number_mc.position = Vector2(digit_transform.z + xoffset, digit_transform.w)

func _digit_transform_at(f: float) -> Vector4:
	# 数字 MC 的 transform 仍按原版 mc_018.xml 的 ct 图层关键帧。
	if f < 9.0:
		return Vector4(1.0, 1.0, DIGIT_BASE_X, DIGIT_BASE_Y)
	if f < 11.0:
		return _lerp_v4(Vector4(0.216995239257813, 0.216995239257813, -5.5, 23.0), Vector4(1.20999145507813, 1.20999145507813, -27.3, -4.35), 9.0, 11.0, f)
	if f < 16.0:
		return _lerp_v4(Vector4(1.20999145507813, 1.20999145507813, -27.3, -4.35), Vector4(1.0, 1.0, DIGIT_BASE_X, DIGIT_BASE_Y), 11.0, 16.0, f)
	if f < 29.0:
		return Vector4(1.0, 1.0, DIGIT_BASE_X, DIGIT_BASE_Y)
	if f < 31.0:
		return _lerp_v4(Vector4(1.0, 0.595993041992188, DIGIT_BASE_X, 21.5), Vector4(1.0, 1.22799682617188, DIGIT_BASE_X, -16.5), 29.0, 31.0, f)
	if f < 35.0:
		return _lerp_v4(Vector4(1.0, 1.22799682617188, DIGIT_BASE_X, -16.5), Vector4(1.0, 1.0, DIGIT_BASE_X, DIGIT_BASE_Y), 31.0, 35.0, f)
	if f < 51.0:
		return Vector4(1.0, 1.0, DIGIT_BASE_X, DIGIT_BASE_Y)
	if f < 54.0:
		return _lerp_v4(Vector4(1.0, 1.0, DIGIT_BASE_X, DIGIT_BASE_Y), Vector4(1.0, 0.0389862060546875, DIGIT_BASE_X, 52.5), 51.0, 54.0, f)
	return Vector4(1.0, 0.0389862060546875, DIGIT_BASE_X, 52.5)

func _lerp_v4(a: Vector4, b: Vector4, f0: float, f1: float, f: float) -> Vector4:
	var denom: float = maxf(0.0001, f1 - f0)
	var t: float = clampf((f - f0) / denom, 0.0, 1.0)
	return a.lerp(b, t)
